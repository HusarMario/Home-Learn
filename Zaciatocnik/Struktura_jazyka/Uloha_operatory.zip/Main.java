public class Main {

    public static void main(String[] args) {

        int a = 51;
        int b = 65;

        System.out.println(a+b+100*78-24);
    }
}
