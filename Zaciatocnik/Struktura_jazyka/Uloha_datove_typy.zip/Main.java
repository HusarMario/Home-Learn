public class Main {

    public static void main(String[] args) {

        byte byteNumber = 2;
        byte byteNumber2 = 35;

        short shortNumber = 374;
        short shortNumber2 = 5766;

        int intNumber = 16516;
        int intNUmber2 = 651651;

        long longNumber = 31355135;
        long longNumber2 = 5615L;

        float floatNumber = 135.88F;
        float floatNumber2 = 54.44F;

        double doubleNumber = 46.654;
        double doubleNumber2 = 465.88;

        boolean booVar = true;
        boolean booVar2 = false;

        char charVar = 'A';
        char charVar2 = 'Z';
    }
}
