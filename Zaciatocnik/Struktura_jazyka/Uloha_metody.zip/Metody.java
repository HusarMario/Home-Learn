public class Metody {

    String outString(){
        return "string of characters";
    }

    int outInt(){
        return 50;
    }

    void outVoid(){
        System.out.println("Nic nevratim");
    }
}
