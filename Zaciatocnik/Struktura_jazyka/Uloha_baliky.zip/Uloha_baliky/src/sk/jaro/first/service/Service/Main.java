package sk.jaro.first.service.Service;

public class Main {

    public static void main(String[] args) {
        System.out.println("Balicek");
    }
}
