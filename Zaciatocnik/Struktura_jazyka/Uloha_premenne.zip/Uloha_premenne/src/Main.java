public class Main {

    public static void main(String[] args) {

    int number1;
    int number2;
    int number3;
    int number4 = 5;
    int number5 = 132;
    int number6 = 1561;
    int number7 = 13;
    int number8 = number4 + number7;
    int number9 = number5 + 1651;
    int number0 = number6 + number6;
    }
}
